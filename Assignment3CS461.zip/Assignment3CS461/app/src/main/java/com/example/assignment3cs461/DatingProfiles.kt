package com.example.assignment3cs461

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DatingProfiles : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dating_profiles)
    }
}